FROZEN AGGREGATE RESULTS

Place Frozen_Results.zip in the repository root, next to reproduce.py.
Before running reproduction, execute from that directory:

    python -m zipfile -e Frozen_Results.zip .

This restores:
    frozen/aggregate_results.json
    frozen/evidence_registry.json

Then follow the existing README reproduction commands, for example:
    python reproduce.py quick --run-dir ../caltransfer_quick

Use a fresh run directory outside the repository. Install requirements.txt first.
The CSV numeric payloads are unchanged. No raw learner records or individual predictions are included.
